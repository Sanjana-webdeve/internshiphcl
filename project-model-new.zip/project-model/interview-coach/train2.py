import pandas as pd
import json
from collections import defaultdict
# from shared_utils.utils import fill_missing_values  # Uncomment if needed later

def run():
    df = pd.read_csv("Software Questions.csv", encoding='latin1')
    df = df.drop_duplicates()

    question_bank = []
    for _, row in df.iterrows():
        question_data = {
            "Category": row['Category'],
            "Question": row['Question'],
            "Difficulty": row.get('Difficulty', 'medium')
        }
        question_bank.append(question_data)

    with open("question_bank.json", "w", encoding='utf-8') as f:
        json.dump(question_bank, f, indent=4)

    grouped_questions = defaultdict(list)
    for q in question_bank:
        grouped_questions[q["Category"]].append({
            "Question": q["Question"],
            "Difficulty": q["Difficulty"]
        })

    with open("grouped_questions.json", "w", encoding='utf-8') as f:
        json.dump(grouped_questions, f, indent=4)

    print(" Training completed: question_bank.json and grouped_questions.json generated.")
