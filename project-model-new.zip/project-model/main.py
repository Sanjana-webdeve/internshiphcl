import sys

if __name__ == "__main__":
    model = sys.argv[1]  # e.g., "medicalmodel"
    action = sys.argv[2]  # e.g., "train" or "predict"

    if model == "medicalmodel":
        if action == "train":
            from medicalmodel.train import run as run_train
            run_train()
        elif action == "predict":
            from medicalmodel.predict import run as run_predict
            run_predict()
        else:
            print("Invalid action. Use 'train' or 'predict'")
    else:
        print("Invalid model name. Supported: medicalmodel")
