import json
import random
import re
import requests
from shared_utils.utils import fill_missing_values  # Not used right now but kept for future use

# Load question data
with open("grouped_questions.json", "r", encoding="utf-8") as f:
    question_data = json.load(f)

# Together API info
TOGETHER_API_URL = "https://api.together.xyz/v1/completions"
TOGETHER_API_KEY = "your_actual_key"

headers = {
    "Authorization": f"Bearer {TOGETHER_API_KEY}",
    "Content-Type": "application/json"
}

def evaluate_answer_together(question, correct_answer, user_answer):
    prompt = f"""
You are an interview evaluator.

Question: {question}

Ideal Answer: {correct_answer}

Candidate's Answer: {user_answer}

Evaluate the candidate's answer. Give a brief review and a score out of 5.
Respond in the format:
Score: <number>/5
Review: <your review>
"""
    data = {
        "model": "mistralai/Mistral-7B-Instruct-v0.3",
        "prompt": prompt,
        "max_tokens": 200,
        "temperature": 0.7,
        "stop": ["Score:", "Review:"]
    }

    response = requests.post(TOGETHER_API_URL, headers=headers, json=data)
    if response.status_code != 200:
        return {"Score": 0, "Review": "Error from API"}

    result_text = response.json().get("choices", [{}])[0].get("text", "")
    
    score_match = re.search(r"Score:\s*(\d(?:\.\d+)?)/5", result_text)
    review_match = re.search(r"Review:\s*(.*)", result_text, re.DOTALL)

    try:
        score = float(score_match.group(1)) if score_match else 0
        review = review_match.group(1).strip() if review_match else "No review found."
    except:
        score = 0
        review = "Could not parse response."

    return {"Score": score, "Review": review}


def run():
    topic = input("Choose a topic: ").strip()
    num_questions = int(input("How many questions do you want? "))

    questions = question_data.get(topic, [])
    if not questions:
        print("Invalid topic.")
        return

    total_score = 0.0
    used_indices = set()

    for i in range(num_questions):
        while True:
            idx = random.randint(0, len(questions) - 1)
            if idx not in used_indices:
                used_indices.add(idx)
                break

        q = questions[idx]
        question_text = q['Question']
        correct_answer = q.get('Answer', 'Not available')
        print(f"\nQuestion {i + 1}: {question_text}")
        answer = input("Your Answer: ")

        result = evaluate_answer_together(question_text, correct_answer, answer)
        print(f"\nScore: {result['Score']}/5")
        print(f"Review: {result['Review']}\n")

        total_score += result['Score']

    print(f"\n✅ Total Score: {total_score} / {5 * num_questions}")
