import pandas as pd
import numpy as np
import joblib

# Load model, scaler, and feature columns
model = joblib.load("house_price_model.pkl")
scaler = joblib.load("scaler.pkl")
feature_columns = joblib.load("feature_columns.pkl")

# Sample input (replace with your own inputs or user interface)
# Must be in the same format as training data with dummy columns
input_data = {
    "LotArea": 8450,
    "OverallQual": 7,
    "YearBuilt": 2003,
    "1stFlrSF": 856,
    "2ndFlrSF": 854,
    "GrLivArea": 1710,
    "GarageCars": 2,
    "GarageArea": 548,
    # Add all necessary one-hot encoded fields
}

# Convert to DataFrame
input_df = pd.DataFrame([input_data])

# Add missing dummy columns from training
for col in feature_columns:
    if col not in input_df.columns:
        input_df[col] = 0

# Arrange in correct column order
input_df = input_df[feature_columns]

# Scale features
scaled_input = scaler.transform(input_df)

# Predict
prediction = model.predict(scaled_input)
print(f"Predicted House Price: ${prediction[0]:,.2f}")
